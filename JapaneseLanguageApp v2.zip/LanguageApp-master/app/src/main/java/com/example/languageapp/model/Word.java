package com.example.languageapp.model;

public class Word {

    private final int mDefaultTranslation;

    private final String mJpTranslation;

    private int mImageResourceId = NO_IMAGE_PROVIDED;

    /** Constant value that represents no image was provided for this word */
    private static final int NO_IMAGE_PROVIDED = -1;

    private final int mAudioResourceId;

    public Word(int defaultTranslation, String mjpTranslation, int audioResourceId) {
        mDefaultTranslation = defaultTranslation;
        mJpTranslation = mjpTranslation;
        mAudioResourceId = audioResourceId;

    }


    public Word(int defaultTranslation, String mjpTranslation, int imageResourceId,int audioResourceId) {
                mDefaultTranslation = defaultTranslation;
                mJpTranslation = mjpTranslation;
                mImageResourceId = imageResourceId;
        mAudioResourceId = audioResourceId;
            }

    public int getmDefaultTranslation() {
        return mDefaultTranslation;
    }


    public String getMjpTranslation() {
        return mJpTranslation;
    }


    public int getImageResourceId() {
        return mImageResourceId;
    }

    /**
         * Returns whether or not there is an image for this word.
         */
     public boolean hasImage() {
               return mImageResourceId != NO_IMAGE_PROVIDED;
            }


            public int getmAudioResourceId(){

                return mAudioResourceId;
            }
}


